package com.test.myapplication;

public class AppConstants {
    public static String BUCKET = "profile"; // Container
    public static String A_K_ID;  // AWS Access Key
    public static String S_K;     // AWS Secret Key
    final static String KEY = "]kYV}(!7P$n5_0i R:?jOWtF/=-pe'AD&@r6%ZXs\"v*N"
            + "[#wSl9zq2^+g;LoB`aGh{3.HIu4fbK)mU8|dMET><,Qc\\C1yxJ";

    public static String encode(String s) {
        StringBuilder sb = new StringBuilder(s.length());

        for (char c : s.toCharArray())
            sb.append(KEY.charAt((int) c - 32));

        return sb.toString();
    }

    public static String decode(String s) {
        StringBuilder sb = new StringBuilder(s.length());

        for (char c : s.toCharArray())
            sb.append((char) (KEY.indexOf((int) c) + 32));

        return sb.toString();
    }

    static {
        StringBuilder sb = new StringBuilder();
        A_K_ID = sb.append(AppConstants.decode("@Nv@N/;Zt2")). //AKIAK8XE6T
                append(AppConstants.decode("r6\"S;6j%9r")). //BCHOXC3DQB
                toString();

        StringBuilder sb2 = new StringBuilder();
        S_K = sb2.append(AppConstants.decode("*Q4Ms94UbKv\\M8jlvC?E[E9")). //JvfpGQflhiIxpm3PIy2qLqQ
                append(AppConstants.decode("s=:E;|#./fq[mI\"?:")). //G91qXnMb8gSLkdH21
                toString();
    }
}
