package com.test.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3Client;

import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private AmazonS3Client s3Client;
    private String userId = UUID.randomUUID().toString();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        s3Client = new AmazonS3Client(new BasicAWSCredentials(AppConstants.A_K_ID, AppConstants.S_K));

        TextView tvDelete = (TextView) this.findViewById(R.id.tvDelete);
        tvDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.deleteProfileImage();
            }
        });
    }

    private void deleteProfileImage() {
        StringBuilder objKey = new StringBuilder();
        objKey.append(this.userId).append("/").append("profile.img");
        this.s3Client.deleteObject(AppConstants.BUCKET, objKey.toString());
    }
}